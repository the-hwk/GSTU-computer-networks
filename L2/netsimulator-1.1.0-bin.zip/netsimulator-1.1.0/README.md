NET-Simulator is an educational application. 
It was created to help lecturers and students in the learning of computer networks. 
Students can build virtural networks in the virtual environment provided by NET-Simulator. 

Website: http://www.net-simulator.org
